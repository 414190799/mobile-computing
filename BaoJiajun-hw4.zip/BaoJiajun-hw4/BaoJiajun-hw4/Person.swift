//
//  Person.swift
//  BaoJiajun-hw4
//
//  Created by Bao, Jiajun on 2/20/18.
//  Copyright © 2018 Bao, Jiajun. All rights reserved.
//

import Foundation
class Person {
    var firstName: String
    var lastName:String
    var age:Int
    var city:String
    var street:String
    var state:String
    var zip:Int
    init(firstName: String,lastName:String,age:Int,city:String,) {
        self.firstName = firstName
        self.lastName=lastName
        self.age=age
        self.city=city
    }
}
