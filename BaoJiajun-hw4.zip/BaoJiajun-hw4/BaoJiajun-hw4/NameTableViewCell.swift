//
//  NameTableViewCell.swift
//  BaoJiajun-hw4
//
//  Created by Bao, Jiajun on 2/20/18.
//  Copyright © 2018 Bao, Jiajun. All rights reserved.
//

import UIKit

class NameTableViewCell: UITableViewCell {

    @IBOutlet weak var firstName: UILabel!
    @IBOutlet weak var lastName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
