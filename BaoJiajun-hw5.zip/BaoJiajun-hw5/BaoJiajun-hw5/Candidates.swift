//
//  Candidates.swift
//  BaoJiajun-hw5
//
//  Created by Bao, Jiajun on 2/26/18.
//  Copyright © 2018 Bao, Jiajun. All rights reserved.
//

import Foundation
class Candidate{
    fileprivate var _firstName:String = ""
    fileprivate var _lastName:String = ""
    fileprivate var _state:String = ""
    fileprivate var _party:String = ""
    
    var firstName:String{
        get {
            return _firstName
        }
        set (newValue) {
            _firstName = newValue
        }
    }
    var lastName:String{
        get {
            return _lastName
        }
        set (newValue) {
            _lastName = newValue
        }
    }
    var state:String{
        get {
            return _state
        }
        set (newValue) {
            _state = newValue
        }
    }
    var party:String{
        get {
            return _party
        }
        set (newValue) {
            _party = newValue
        }
    }
    
    init(firstName:String, lastName:String, state:String, party:String){
        self.firstName=firstName
        self.lastName=lastName
        self.state=state
        self.party=party
    }
    
    convenience init() {
        self.init(firstName:"z", lastName:"x", state:"c", party:"v")
    }
    
    
}
