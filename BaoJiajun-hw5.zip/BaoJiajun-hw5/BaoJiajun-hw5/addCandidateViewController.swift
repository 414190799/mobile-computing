//
//  addCandidateViewController.swift
//  BaoJiajun-hw5
//
//  Created by Bao, Jiajun on 2/26/18.
//  Copyright © 2018 Bao, Jiajun. All rights reserved.
//

import UIKit
import CoreData

class addCandidateViewController: UIViewController {
    
    var currentPosition=0
    var party="p"
    var candidates = [NSManagedObject]()
    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var state: UITextField!
    @IBOutlet weak var sgparty: UISegmentedControl!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func action(_ sender: Any) {
        self.currentPosition = self.sgparty.selectedSegmentIndex
        if currentPosition==1{
            party = "Republican"
        }else{
            party = "Democrat"
        }
    }

    @IBAction func save(_ sender: Any) {
        label.text="Candidate Saved"
        savePerson(firstName:firstName.text!, lastName:lastName.text!, state:state.text!, party:party)
    }
    
    func savePerson(firstName: String, lastName: String, state:String, party:String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        let entity =  NSEntityDescription.entity(forEntityName: "Candidates", in: managedContext)
        let candidate = NSManagedObject(entity: entity!, insertInto:managedContext)
        candidate.setValue(firstName, forKey: "firstName")
        candidate.setValue(lastName, forKey: "lastName")
        candidate.setValue(state, forKey: "state")
        candidate.setValue(party, forKey: "party")
        do {
            try managedContext.save()
        } catch {
            // what to do if an error occurs?
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        candidates.append(candidate)
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
