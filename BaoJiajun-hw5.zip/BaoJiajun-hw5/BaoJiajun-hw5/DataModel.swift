//
//  DataModel.swift
//  BaoJiajun-hw5
//
//  Created by Bao, Jiajun on 2/26/18.
//  Copyright © 2018 Bao, Jiajun. All rights reserved.
//

import Foundation
class DataModel {
    
    fileprivate var list:[Candidate] = [Candidate]()
    
    init() {
        // Create the list of people
        list.append(Candidate(firstName:"Carly", lastName:"Fiorina", state:"Virginia", party:"Republican"))

    }
    
    func count() -> Int {
        return list.count
    }
    
    func get(index:Int) -> Candidate {
        if index < list.count {
            return list[index]
        } else {
            return Candidate(firstName:"x", lastName:"x", state:"x", party:"x")
        }
    }
    
    func add(person:Candidate) {
        list.append(person)
    }
    
    func delete(index:Int) {
        if index < list.count {
            list.remove(at: index)
        }
    }
}
